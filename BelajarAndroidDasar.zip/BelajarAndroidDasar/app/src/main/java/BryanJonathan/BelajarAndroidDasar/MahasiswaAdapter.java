package BryanJonathan.BelajarAndroidDasar;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MahasiswaAdapter extends RecyclerView.Adapter<MahasiswaAdapter.MahasiswaViewHolder> {
    private ArrayList<Mahasiswa> listMahasiswa;

    public MahasiswaAdapter(ArrayList<Mahasiswa> listMahasiswa) {
        this.listMahasiswa = listMahasiswa;
    }

    @NonNull
    @Override
    public MahasiswaAdapter.MahasiswaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_data, parent, false);
        return new MahasiswaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MahasiswaAdapter.MahasiswaViewHolder holder, int position) {
        holder.tv_nama.setText(listMahasiswa.get(position).getNama());
        holder.tv_nim.setText(listMahasiswa.get(position).getNim());
        holder.tv_jurusan.setText(listMahasiswa.get(position).getJurusan());
    }

    @Override
    public int getItemCount() {
        return (listMahasiswa != null) ? listMahasiswa.size() : 0;
    }

    public class MahasiswaViewHolder extends RecyclerView.ViewHolder{
        private TextView tv_nama, tv_nim, tv_jurusan;

     public MahasiswaViewHolder (View view){
         super(view);
         tv_nama = view.findViewById(R.id.tv_nama);
         tv_nim = view.findViewById(R.id.tv_nim);
         tv_jurusan = view.findViewById(R.id.tv_jurusan);
     }
    }
}
